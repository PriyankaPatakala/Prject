package com.cap.bank.exceptions;

public class BankCustomerNotFound extends Exception {

	public BankCustomerNotFound(String Message)
		{
			super(Message);
		}

	public void getMessage(String string) {
		// TODO Auto-generated method stub
		
	}

	

	}

