package com.cap.bank.services;

import java.util.List;

import com.cap.bank.beans.BankCustomer;
import com.cap.bank.exceptions.BankCustomerNotFound;
import com.cap.bank.beans.Transaction;

public interface IBankCustomerServices {
	
	public boolean createAccount(BankCustomer bean) throws BankCustomerNotFound;

	public double showBalance(BankCustomer m) throws BankCustomerNotFound;
	
	public boolean valid(long id) throws BankCustomerNotFound;
	
	//public boolean valid(int pin);
	
	public BankCustomer displayAccountholder1(long id) throws BankCustomerNotFound;
	
	public double  deposit(BankCustomer e,double amount) throws BankCustomerNotFound;
	
	public double withDraw(BankCustomer d, double amount) throws BankCustomerNotFound;
	
	public int fundTransfer(BankCustomer b,BankCustomer c,double amount) throws BankCustomerNotFound;
	
	//public Accountholder1 printTransactions(Accountholder1 a) throws Accountholder1NotFound;
	
	public List<Transaction> printTrans(long id7) throws BankCustomerNotFound;
}
