package com.cap.bank.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.cap.bank.beans.BankCustomer;
import com.cap.bank.beans.Transaction;
import com.cap.bank.exceptions.BankCustomerNotFound;
import com.cap.bank.services.BankCustomerServicesImp;

public class Testclass extends BankCustomerServicesImp {

	BankCustomer a= new BankCustomer(1,"priya","Telangana",23,
			null,"8328514096", "8956985698",51880,
			10000);
	BankCustomer b= new BankCustomer(2,"aarush","Telangana",54,
			"priya@gmail.com","8328514096", "8985962398",518,
			1000);

	BankCustomerServicesImp c = new BankCustomerServicesImp();
	@Test
	public void testCreateAccount() throws BankCustomerNotFound {

		a.setEmailid("priya@gmail.com");
		boolean b=c.createAccount(a);
		assertTrue(b==true);
	}
	@Test
	public void testShowBalance() {

		assertEquals(10000, a.getBalance(),0.1);
	}

	@Test
	public void testDeposit() throws BankCustomerNotFound {
		double e=c.deposit(b,1000);
		assertEquals(2000, b.getBalance(),0.1);

	}

	@Test
	public void testWithDraw() throws BankCustomerNotFound {
		double withdraw=c.withDraw(b,200);
		assertEquals(800,b.getBalance(),0.1);

	}


	@Test
	public void testFundTransfer() throws BankCustomerNotFound {
		double a3= c.fundTransfer(a,b,1000);
		assertEquals(9000, a.getBalance(),0.1);
		assertNotEquals(1000,b.getBalance(),0.1);

	}

	@Test
	public void testPrintTransactions() throws BankCustomerNotFound {

		assertNotNull(c);
	}

}
