package com.capgemini.mps.dto;

public class Mobile
{
 public Mobile(Long mobileId, String name, double price, Integer quantity)
    {
		super();
		this.mobileId = mobileId;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
public Mobile() {
	// TODO Auto-generated constructor stub
}
private Long mobileId;
 private String name;
 private double price;
 private Integer quantity;
 
public Long getMobileId()
{
	return mobileId;
}
public void setMobileId(Long mobileId) 
{
	this.mobileId = mobileId;
}
public String getName()
{
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public Integer getQuantity() {
	return quantity;
}
public void setQuantity(Integer quantity) {
	this.quantity = quantity;
}
@Override
public String toString() {
	return "Mobile [mobileId=" + mobileId + ", name=" + name + ", price="
			+ price + ", quantity=" + quantity + "]";
}
}
