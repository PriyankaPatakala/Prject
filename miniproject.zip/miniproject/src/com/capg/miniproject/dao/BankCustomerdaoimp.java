
package com.capg.miniproject.dao;

import java.util.HashMap;

import com.capg.miniproject.beans.BankCustomer;



public class BankCustomerdaoimp implements IBankCustomerdao{

    HashMap<Long,BankCustomer> acctList = new HashMap<Long,BankCustomer>();
    
    public boolean createAccount(BankCustomer bean) {
        Long key=bean.getAccno();
        acctList.put(key,bean);
        return acctList.containsValue(bean);
        
    }
    public BankCustomer displayBankCustomer(long id3) {
    	BankCustomer cust=null;
        for (BankCustomer c : acctList.values()) {
      if(c.getAccno() == id3){
        cust=c;  
      }
      }
        return cust;
    }

    public boolean valid(long id3)
    { boolean flag=true;
        for (BankCustomer c : acctList.values()) {
              if(c.getAccno() == id3){
                 flag=false;
              }
              
                  
              }
        return flag;
    }
    
    
    public boolean valid(int pin)
    {  boolean flag=true;
        for (BankCustomer c : acctList.values()) {
              if(c.getPin() == pin){
                  flag=false;;
              }
             
              }
        return flag;
    }
    
    public double showBalance(BankCustomer m) {
                double balance=0;
                 balance= m.getBalance();
                 return balance;
            
           }
            public double deposit(BankCustomer e,double amount) 
            {
                
                double currbal=0;
                      currbal=(currbal+e.getBalance()+amount);
                     e.setBalance(currbal);
                 return currbal;
            }
                
@Override
    public double withDraw(BankCustomer d,double amount2) 
{ 
    double currbal=0;
      
                     if(d.getBalance()-amount2>500) 
                    {
                     currbal=(currbal+d.getBalance()-amount2);
                     d.setBalance(currbal);
                   
                     }
                     else
                     return 0;
                
              return currbal;
}
      
        

    @Override
    public int fundTransfer(BankCustomer b,BankCustomer c, double amount3)
    {
          
        double currbal1=0;
        double currbal2=0;
                     if((amount3<b.getBalance())&&(b.getBalance()-amount3>500))
                                  {
                                           currbal1=(currbal1+b.getBalance()-amount3);
                                           b.setBalance(currbal1);
                                           currbal2=(currbal2+c.getBalance()+amount3);
                                           c.setBalance(currbal2);
                                    }
                                  else
                                      return 0;
            
            return 1;       
    }
            
        

        
    public boolean printTransactions(long id7){
        return false;
        
    }
    
    
    
    
    
    }

