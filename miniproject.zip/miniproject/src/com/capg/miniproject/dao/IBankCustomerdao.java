
package com.capg.miniproject.dao;

import com.capg.miniproject.beans.BankCustomer;

public interface IBankCustomerdao  
{
    public boolean createAccount(BankCustomer bean);

    public double showBalance(BankCustomer m);
    
    public boolean valid(long id);
    
    public boolean valid(int pin);
    
    public BankCustomer displayBankCustomer(long id);
    
    public double deposit(BankCustomer e,double amount);
    
    public double withDraw(BankCustomer d,double amount);
    
    public int fundTransfer(BankCustomer b,BankCustomer c,double amount);
    
    public boolean printTransactions(long id7);

} 
