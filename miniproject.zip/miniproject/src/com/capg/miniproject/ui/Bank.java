package com.capg.miniproject.ui;

import java.util.Scanner;

import com.capg.miniproject.beans.BankCustomer;
import com.capg.miniproject.service.IBankCustomerserviceimp;
import com.capg.miniproject.exception.BankCustomerexception;


public class Bank {

       public static void main(String[] args) {
        
        
    	   IBankCustomerserviceimp service = new IBankCustomerserviceimp();
         long recno=1000;
        while(true)
             {
            System.out.println("Welcome to bank");
            System.out.println("1.Create Account");
            System.out.println("2.Show Balance");
            System.out.println("3.Deposit Amount");
            System.out.println("4.Withdraw Amount");
            System.out.println("5.Fund transfer");
            System.out.println("6 Print Transactions");
            System.out.println("7.Exit");
            
            BankCustomer bean = new BankCustomer();
            @SuppressWarnings("resource")
            Scanner sc = new Scanner(System.in);

            int choice = sc.nextInt();
            switch (choice) {

            
            case 1:  int age; String emailid; String accName;
                     StringBuffer addr ;StringBuffer mobNum; 
                     StringBuffer idProofNo;
                   do{
                      System.out.println("enter  your Name");
                      accName = sc.next();
                     } while(service.validateAccname(accName));
                        
                   do{
                        System.out.println("enter your Address");
                        addr = new StringBuffer();
                            //addr.append(sc.next());
                            //addr.append(System.lineSeparator());
                            //addr.append(sc.next());
                            //addr.append(System.lineSeparator());
                            addr.append(sc.next());
                     }  while(service.validateAddress(addr));
                            
                    do{     
                        System.out.println("enter your mobile number");
                        mobNum= new StringBuffer();
                        mobNum.append(sc.next());
                      } while(service.validatemobNum(mobNum));
                     
                     do{
                        System.out.println("enter your Id Proof Number");
                        idProofNo= new StringBuffer();
                        idProofNo.append(sc.next());
                       } while(service.validateidProof(idProofNo));
                     
                     do{
                        System.out.println("enter your Age");
                        age = sc.nextInt();
                      } while(service.validateAge(age));
                   
                     do{
                       System.out.println("enter your Email id");
                       emailid = sc.next();
                       }while(service.validateEmailId(emailid));
                     
                      long accno= recno;
                     
                       bean.setAccno(accno);
                       recno++;
                       bean.setAccName(accName);
                       bean.setAddr(addr);
                       bean.setAge(age);
                       bean.setEmailid(emailid);
                       bean.setIdProofNo(idProofNo);
                       bean.setMobNum(mobNum);
                     
                       int pinno=(int)(Math.random()*100000);
                       bean.setPin(pinno);
                       boolean isAdded=service.createAccount(bean);
                        if(isAdded)
                        {
                        double balance=500;
                        System.out.println("Created account successfully");
                        System.out.println("minimum balance should be 500");
                        bean.setBalance(balance);
                        System.out.println(bean);
                        
                         }
                    else
                        System.out.println(" SORRY Account not created");
            
                    break;
                    
            case 2:
                   System.out.println("Enter your account Number");
                  long   id=sc.nextLong();
                    
                     boolean val=service.valid(id);
                     if(val)
                     {
                         try {
                             throw new BankCustomerexception("valid");
                             }
                         catch(BankCustomerexception x)
                         {
                            System.out.println("Enter valid account number");
                            System.out.println(" "); 
                         }
                     }
                     else
                     {
                     System.out.println("enter your pin");
                     int pin= sc.nextInt();
                     boolean val1=service.valid(pin);
                     if(val1)
                        {
                         try {
                             throw new BankCustomerexception("enter valid pin number");
                             } 
                             catch(BankCustomerexception x)
                            {
                             System.out.println("Enter valid pin number"); 
                             System.out.println(" ");
                         }
                     }
                     else
                     {    BankCustomer m = service.displayBankCustomer(id);
                         boolean valid1=service.validateAccnoPinno( m,id,pin);
                         if(valid1)
                         {
                         double a= service.showBalance(m);
                      System.out.println("your current balance is"+a);
                         }
                     
                     else
                     {
                         try {
                             throw new BankCustomerexception("account number and pin are not matched");
                             } 
                             catch(BankCustomerexception x)
                            {
                             System.out.println("Account number and pin are not matched"); 
                             System.out.println(" ");
                         } 
                     }
                         }
                     }
                     
            
                          break;
                          
                          
            case 3:System.out.println("Enter your account Number");
                  long  id1=sc.nextLong();
             
                  
                  boolean val1=service.valid(id1);
                 if(val1)
                 {
                     try {
                         throw new BankCustomerexception("enter valid accountnumber");
                         } 
                        catch(BankCustomerexception x)
                          {
                         System.out.println("Enter valid account number"); 
                         System.out.println(" "); 
                           }
                 }
                 else
                 {
                 System.out.println("enter your pin");
                 int pin1= sc.nextInt();
                 
                 boolean val2=service.valid(pin1);
                 if(val2)
                 {
                     try {
                         throw new BankCustomerexception("enter valid pin number");
                        }
                         catch(BankCustomerexception x)
                         {
                         System.out.println("Enter valid pin number");
                         System.out.println(" ");
                         }
                 }
                 else
                 {
                 System.out.println("enter the amount to be deposited");
                    double amount=sc.nextInt();
                    BankCustomer e = service.displayBankCustomer(id1);
                    boolean valid1=service.validateAccnoPinno( e,id1,pin1);
                     if(valid1)
                     {
                double a1= service.deposit(e,amount);
                System.out.println("your current balance is"+a1);
                 }
                     else
                     {
                         try {
                             throw new BankCustomerexception("account number and pin are not matched");
                             } 
                             catch(BankCustomerexception x)
                            {
                             System.out.println("Account number and pin are not matched"); 
                             System.out.println(" ");
                         } 
                     }
                 }
                 }
                break;
                
                
            case 4: 
                    System.out.println("Enter your account Number");
                    long  id2=sc.nextLong();
                    
                    boolean val4=service.valid(id2);
                 if(val4)
                 {
                     try {
                         throw new BankCustomerexception("enter valid accountnumber");
                        }
                         catch(BankCustomerexception x)
                         {
                         System.out.println("Enter valid account number");
                         System.out.println(" ");
                         }
                 }
                 else
                 {
              
                 System.out.println("enter your pin");
                 int pin2= sc.nextInt();
                 
                 boolean val2=service.valid(pin2);
                 if(val2)
                   {
                     try {
                         throw new BankCustomerexception("enter valid pin number");
                        }
                         catch(BankCustomerexception x)
                        {
                         System.out.println("Enter valid pin number"); 
                         System.out.println(" "); 
                         }
                 }
                 else
                 {
                  
                	 BankCustomer d = service.displayBankCustomer(id2);
                  boolean valid1=service.validateAccnoPinno( d,id2,pin2);
                     if(valid1)
                     {
                         System.out.println("enter the amount to be withdraw");
                      double amount2=sc.nextInt();
                  double a2= service.withDraw(d,amount2);
                          if(a2==0)
                           {
                               try {
                         throw new BankCustomerexception("insufficient balance");
                                      }
                                 catch(BankCustomerexception x)
                                  {
                                  System.out.println("Insufficient balance");
                                  System.out.println(" "); 
                                   }
                            }
                 else
                System.out.println("your current balance is "+a2);
                 }
                     else
                     {
                         try {
                             throw new BankCustomerexception("account number and pin are not matched");
                             } 
                             catch(BankCustomerexception x)
                            {
                             System.out.println("Account number and pin are not matched"); 
                             System.out.println(" ");
                         } 
                     }
                 }
                 }
                break;
                
            case 5:  System.out.println("Enter your account Number");
                     long  id3=sc.nextLong();
                     BankCustomer b = service.displayBankCustomer(id3);
                        

                     boolean val6=service.valid(id3);
                  if(val6)
                       {
                        try {
                         throw new BankCustomerexception("enter valid accountnumber");
                            }
                        catch(BankCustomerexception x)
                          {
                         System.out.println("Enter valid account number");
                         System.out.println(" ");
                          }
                      }
                 else
                 {
                 System.out.println("enter your pin");
                 int pin3= sc.nextInt();
                 boolean val5=service.valid(pin3);
                 if(val5)
                 {
                     try {
                         throw new BankCustomerexception("enter valid pin number");
                          }
                     catch(BankCustomerexception x)
                         {
                         System.out.println("Enter valid pin number"); 
                         System.out.println(" ");
                         }
                 }
                 else
                 {
                     boolean valid1=service.validateAccnoPinno( b,id3,pin3);
                     if(valid1)
                     {
                 System.out.println("Enter account Number you want to transfer");
                  long  id4=sc.nextLong();
                  BankCustomer c = service.displayBankCustomer(id4);
                  boolean val7=service.valid(id4);
                  if(val7)
                     {
                      try {
                             throw new BankCustomerexception("enter valid accountnumber");
                         }catch(BankCustomerexception x){
                             System.out.println("Enter valid account number");
                             System.out.println(" ");
                         }
                     }
                  else
                  {
                  System.out.println("enter the amount to be transfer");
                    double amount3=sc.nextInt();
                    int a3= service.fundTransfer(b,c,amount3);
                    if(a3==0)
                   {
                        try {
                             throw new BankCustomerexception("Insufficient balance");
                         }catch(BankCustomerexception x){
                             System.out.println("insufficient balance");
                             System.out.println(" ");
                         }
                   }
        
                else
                    {
                       System.out.println("Transaction succesfully completed");
                       System.out.println("remaining balance of Accno: "+id3+" is "+b.getBalance());
                       System.out.println("Updated balance of Accno: "+id4+" is "+c.getBalance());
                     }
                  }
                 }
                     else
                     {
                         try {
                             throw new BankCustomerexception("account number and pin are not matched");
                             } 
                             catch(BankCustomerexception x)
                            {
                             System.out.println("Account number and pin are not matched"); 
                             System.out.println(" ");
                         } 
                     }
                 }
                 }
                    break;
                    case 6:
                         System.out.println("enter your account number");
                         long  id7=sc.nextLong();
                         BankCustomer c = service.displayBankCustomer(id7);
                         boolean val7=service.valid(id7);
                          if(val7)
                             {
                              try {
                                     throw new BankCustomerexception("enter valid accountnumber");
                                   } 
                               catch(BankCustomerexception x)
                                   {
                                     System.out.println("Enter valid account number"); 
                                     System.out.println(" ");
                                   }
                             }
                             else
                             {
                             System.out.println("enter your pin");
                             int pin3= sc.nextInt();
                             boolean val5=service.valid(pin3);
                             if(val5)
                             {
                                 try {
                                     throw new BankCustomerexception("enter valid pin number");
                                    }
                                    catch(BankCustomerexception x)
                                    {
                                     System.out.println("Enter valid pin number");
                                     System.out.println(" ");
                                     }
                             }
                             boolean valid1=service.validateAccnoPinno( c,id7,pin3);
                             if(valid1)
                             {
                            boolean a= service.printTransactions(id7);
                              }
                             else {
                                 try {
                                     throw new BankCustomerexception("account number and pin are not matched");
                                     } 
                                     catch(BankCustomerexception x)
                                    {
                                     System.out.println("Account number and pin are not matched"); 
                                     System.out.println(" ");
                                 } 
                             }
                            }
            
            }
            }
        
        }
}